library(scriptests)
runScripTests()
