library(scriptests)
runScripTests()
