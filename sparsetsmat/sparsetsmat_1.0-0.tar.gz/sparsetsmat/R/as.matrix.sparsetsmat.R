as.matrix.sparsetsmat <- function(x, ...) {
    x[ , , drop=FALSE]
}
