as.data.frame.sparsetsmat <- function(x, ...) {
    # be careful to add one NA for an id that does not appear in the data
    df <- list(x$date, rep(x$id[order(x$id.idx)], x$id.noc), x$value)
    names(df) <- x$df.colnames
    y <- as.data.frame(df, row.names=NULL)
    attr(y, 'id') <- x$id
    attr(y, 'backfill') <- x$backfill
    attr(y, 'sort.ids') <- x$sort.ids
    class(y) <- c('sparsetsmat.df', 'data.frame')
    y
}
